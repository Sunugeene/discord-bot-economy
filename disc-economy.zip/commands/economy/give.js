const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const economy = require("../../utils/economy");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("give")
        .setDescription("Передать монеты другому пользователю")
        .addUserOption(option =>
            option.setName("пользователь")
                .setDescription("Кому передать монеты")
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option.setName("сумма")
                .setDescription("Сколько монет передать")
                .setRequired(true)
        ),

    async execute(interaction) {
        const sender = interaction.user;
        const receiver = interaction.options.getUser("пользователь");
        const amount = interaction.options.getInteger("сумма");

        if (receiver.id === sender.id) {
            return interaction.reply({
                content: "Вы не можете передавать монеты самому себе!",
                flags: 64
            });
        }

        if (amount <= 0) {
            return interaction.reply({
                content: "Сумма должна быть больше 0!",
                flags: 64
            });
        }

        const senderBalance = economy.getCoins(sender.id);
        if (senderBalance < amount) {
            return interaction.reply({
                content: "У вас недостаточно монет!",
                flags: 64
            });
        }

        // Снимаем у отправителя и добавляем получателю
        economy.addCoins(sender.id, -amount);
        economy.addCoins(receiver.id, amount);

        const embed = new EmbedBuilder()
            .setTitle("Передача монет")
            .setDescription(`${sender}, Вы передали **${amount}** монет пользователю ${receiver}.`)
            .setColor("White");

        await interaction.reply({ embeds: [embed] });
    }
};
