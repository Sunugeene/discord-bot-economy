const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const economy = require("../../utils/economy");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("balance")
        .setDescription("Показать баланс пользователя")
        .addUserOption(option =>
            option.setName("пользователь")
                .setDescription("Выберите пользователя (необязательно)")
                .setRequired(false)
        ),

    async execute(interaction) {
        const target = interaction.options.getUser("пользователь") || interaction.user;
        const coins = economy.getCoins(target.id);

        const embed = new EmbedBuilder()
            .setTitle(`Баланс пользователя - ${target.username.toLowerCase()}`)
            .setDescription(`• Монет:\n**${coins}**`)
            .setColor("White");

        await interaction.reply({ embeds: [embed] });
    }
};
