const fs = require("fs");

const file = "economy.json";

function load() {
    return JSON.parse(fs.readFileSync(file, "utf8"));
}

function save(data) {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

module.exports = {
    addCoins(id, amount) {
        const db = load();
        if (!db[id]) db[id] = { coins: 0, lastTimely: 0 };
        db[id].coins += amount;
        save(db);
    },

    getCoins(id) {
        const db = load();
        if (!db[id]) return 0;
        return db[id].coins;
    },

    canClaimTimely(id, cooldown = 10) {
        const db = load();
        if (!db[id]) return true;
        const now = Date.now();
        return now - db[id].lastTimely >= cooldown * 60 * 1000;
    },

    setTimelyTime(id) {
        const db = load();
        if (!db[id]) db[id] = { coins: 0, lastTimely: 0 };
        db[id].lastTimely = Date.now();
        save(db);
    }
};
