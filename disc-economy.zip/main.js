const { Client, Collection, GatewayIntentBits, REST, Routes } = require("discord.js");
const fs = require("fs");
const path = require("path");

// === ДАННЫЕ БОТА ===
const TOKEN = "MTQzNDgxNTEwNTI2MjE2MTk3Mw.GwYW9I.-goNULhl2W-CXFxN_trk9t50AgsWkF3ljpDsAw";
const CLIENT_ID = "1434815105262161973";
const GUILD_ID = "1434814158552961024"; // Для теста на одном сервере

// === КЛИЕНТ ===
const client = new Client({
    intents: [GatewayIntentBits.Guilds]
});

client.commands = new Collection();
const commandsArray = [];

// === ЗАГРУЗКА КОМАНД ===
function loadCommands(folder) {
    const files = fs.readdirSync(folder);

    for (const file of files) {
        const filePath = path.join(folder, file);
        const stat = fs.statSync(filePath);

        if (stat.isDirectory()) {
            loadCommands(filePath);
        } else if (file.endsWith(".js")) {
            const command = require(filePath);
            client.commands.set(command.data.name, command);
            commandsArray.push(command.data.toJSON());
        }
    }
}

loadCommands(path.join(__dirname, "commands"));

// === РЕГИСТРАЦИЯ SLASH-КОМАНД ===
const rest = new REST({ version: "10" }).setToken(TOKEN);

async function registerCommands() {
    try {
        console.log("⏳ Регистрирую slash-команды...");
        
        await rest.put(
            Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID),
            { body: commandsArray }
        );

        console.log("✅ Команды зарегистрированы!");
    } catch (error) {
        console.error("❌ Ошибка регистрации команд:", error);
    }
}

// === ОБРАБОТЧИК КОМАНД ===
client.on("interactionCreate", async interaction => {
    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
        await command.execute(interaction);
    } catch (err) {
        console.error(err);
        interaction.reply({ content: "❌ Ошибка выполнения команды.", flags: 64 });
    }
});

// === ЗАПУСК БОТА ===
client.once("clientReady", () => {
    console.log(`✅ Бот запущен как ${client.user.tag}`);
});

(async () => {
    await registerCommands();
    await client.login(TOKEN);
})();
