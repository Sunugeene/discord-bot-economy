const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const economy = require("../../utils/economy");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("timely")
        .setDescription("Получить временную награду (каждые 10 минут)"),

    async execute(interaction) {
        const user = interaction.user;

        const canClaim = economy.canClaimTimely(user.id, 10); // 10 минут
        if (!canClaim) {
            return interaction.reply({
                content: "Вы уже получили награду, попробуйте позже!",
                flags: 64
            });
        }

        economy.addCoins(user.id, 100);
        economy.setTimelyTime(user.id);

        const embed = new EmbedBuilder()
            .setTitle(`Временная награда - ${user.username.toLowerCase()}`)
            .setDescription(`Вы получили **100** монет. Приходите через **10 минут!**`)
            .setColor("White");

        await interaction.reply({ embeds: [embed] });
    }
};
