const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const economy = require("../../utils/economy");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("casino")
        .setDescription("Сыграть в казино 50/50")
        .addIntegerOption(option =>
            option.setName("ставка")
                .setDescription("Сколько монет поставить")
                .setRequired(true)
        ),

    async execute(interaction) {
        const user = interaction.user;
        const bet = interaction.options.getInteger("ставка");

        const balance = economy.getCoins(user.id);

        if (bet <= 0) 
            return interaction.reply({ content: "Ставка должна быть больше 0!", flags: 64 });

        if (bet > balance)
            return interaction.reply({ content: "У вас недостаточно монет!", flags: 64 });

        const win = Math.random() < 0.5;

        let embed;

        if (win) {
            economy.addCoins(user.id, bet);
            embed = new EmbedBuilder()
                .setTitle("Казино")
                .setDescription(`Вы выиграли **${bet}** монет!`)
                .setColor("White");
        } else {
            economy.addCoins(user.id, -bet);
            embed = new EmbedBuilder()
                .setTitle("Казино")
                .setDescription(`Вы проиграли и ничего не получили.`)
                .setColor("White");
        }

        await interaction.reply({ embeds: [embed] });
    }
};
