const { SlashCommandBuilder, EmbedBuilder, PermissionFlagsBits } = require("discord.js");
const economy = require("../../utils/economy");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("award")
        .setDescription("Выдать монеты пользователю (только админам)")
        .addUserOption(option =>
            option.setName("пользователь")
                .setDescription("Кому выдать монеты")
                .setRequired(true)
        )
        .addIntegerOption(option =>
            option.setName("сумма")
                .setDescription("Сколько монет выдать")
                .setRequired(true)
        )
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

    async execute(interaction) {
        const target = interaction.options.getUser("пользователь");
        const amount = interaction.options.getInteger("сумма");
        const admin = interaction.user;

        if (amount <= 0) 
            return interaction.reply({ content: "Сумма должна быть больше 0!", flags: 64 });

        economy.addCoins(target.id, amount);

        const embed = new EmbedBuilder()
            .setTitle("Выдача монет")
            .setDescription(`Администратор ${admin} выдал **${amount}** монет пользователю ${target}.`)
            .setColor("White");

        await interaction.reply({ embeds: [embed] });
    }
};
